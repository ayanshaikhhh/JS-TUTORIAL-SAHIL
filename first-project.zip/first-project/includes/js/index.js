const onLoad = async () => {
  const users = await getUsers();
  renderTable(users);
};

const getUsers = async () => {
  //  loader.style.display = "block";
  let response = await fetch("https://jsonplaceholder.typicode.com/users");
  return await response.json();
  // userData = data;
  // loader.style.display = "none";
  // tableData(userData);
};

const renderTable = (data) => {
  const table = getTableElement(data);
  const ele = document.getElementById("users-section");
  ele.append(table);
};

const getTableElement = (data) => {
  const table = document.createElement("table");
  const thead = document.createElement("thead");
  const tbody = document.createElement("tbody");

  const columns = ["id", "name", "email", "phone", "username", "website"];

  const thElements = [];

  columns.forEach((current) => {
    const th = getTh(current);
    thElements.push(th);
  });

  const bodyFragment = document.createDocumentFragment();
  data.forEach((current) => {
    const tdElements = [];
    columns.forEach((col) => {
      const value = current[col];
      const td = getTDElement(value);
      tdElements.push(td);
    });
    const tr = getRowElement(tdElements);
    bodyFragment.append(tr);
  });

  const thRow = getRowElement(thElements);
  thead.append(thRow);

  table.append(bodyFragment);

  table.append(thead);
  table.append(tbody);
  return table;
};
const getTh = (columnName) => {
  const th = document.createElement("th");
  th.innerHTML = columnName;
  return th;
};
const getRowElement = (elements) => {
  const tr = document.createElement("tr"); // ✅ correct method
  tr.append(...elements);
  return tr;
};
const getTDElement = (value) => {
  const td = document.createElement("td");
  td.innerHTML = value;
  return td;
};
window.addEventListener("load", onLoad);
